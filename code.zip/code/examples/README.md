#### LRV-Instruction can equip the LMM with the ability to say no and also provide correct answers, even though there is no chart image in LRV-Instruction dataset.

<p align="center">
    <a href="https://llava.hliu.cc/"><img src="../chart_example1.jpg" width="70%"></a> <br>
</p>

The original image doesn't have the red box. I just want to highlight 'Japan'.
